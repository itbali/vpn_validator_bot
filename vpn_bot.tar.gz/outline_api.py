import requests
from config import OUTLINE_API_URL, OUTLINE_CERT_SHA256

class OutlineVPN:
    def __init__(self):
        self.api_url = OUTLINE_API_URL
        self.cert_sha256 = OUTLINE_CERT_SHA256

    def create_access_key(self, name: str) -> dict:
        """Create a new access key for a user"""
        response = requests.post(
            f"{self.api_url}/access-keys",
            verify=self.cert_sha256,
            json={"method": "POST"}
        )
        if response.status_code == 201:
            key_data = response.json()
            # Rename the key with user information
            self.rename_key(key_data['id'], name)
            return key_data
        return None

    def delete_access_key(self, key_id: str) -> bool:
        """Delete an access key"""
        response = requests.delete(
            f"{self.api_url}/access-keys/{key_id}",
            verify=self.cert_sha256
        )
        return response.status_code == 204

    def rename_key(self, key_id: str, name: str) -> bool:
        """Rename an access key"""
        response = requests.put(
            f"{self.api_url}/access-keys/{key_id}/name",
            verify=self.cert_sha256,
            json={"name": name}
        )
        return response.status_code == 204

    def get_all_keys(self) -> list:
        """Get all access keys"""
        response = requests.get(
            f"{self.api_url}/access-keys",
            verify=self.cert_sha256
        )
        if response.status_code == 200:
            return response.json().get('accessKeys', [])
        return [] 